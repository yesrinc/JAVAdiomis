
package diomipiz;

import diomipiz.IGU.PantallaPrincipal;

/**
 *
 * @author yese1
 */
public class DiomiPiz {

    /**
     * @param args the command line arguments
     */
    
            
    public static void main(String[] args) {
         
        
        PantallaPrincipal princ = new PantallaPrincipal();
        princ.setVisible(true);
        princ.setLocationRelativeTo(null);
       


// TODO code application logic here
    }
    
}
