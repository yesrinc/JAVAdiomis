
package diomipiz.IGU;

import javax.swing.JDialog;

/**
 *
 * @author yese1
 */
class JOptionPane {

    JOptionPane(String se_guardo_correctamente) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    JDialog createDialog(String guardado_Exitoso) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
